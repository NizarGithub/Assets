<!-- Side Box Begin -->
<a href="?page=logout" onClick="return confirm('Apakah Anda yakin akan keluar?')"><img src="images/logout.jpeg" border="0" /></a>
<div class="side-box-top"></div>
<div class="side-box-middle">
<img src="<?php echo $_SESSION['gambar_user'];?>" width="200" height="200" border="0" />
<br />
<br />
</div>
<div class="side-box-bottom"></div>