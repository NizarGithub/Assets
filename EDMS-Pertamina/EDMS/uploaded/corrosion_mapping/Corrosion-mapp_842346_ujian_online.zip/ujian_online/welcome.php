<div>
    <h1>Assalamualaiku...<?php 
	if(isset($_SESSION['id_user'])){
	
		echo ucwords($_SESSION['username']);
	
	}
	?></h1>

    <p>Situs ujian online ini digunakan untuk melaksanakan ujian secara online. user dapat melaksanakan ujian kapan saja dan dimana saja.</p>
    
    
    <p>Sebelum mengikuti ujian, user harus mendaftar sebagai anggota situs ujian online. dan melakukan LOGIN sebelum melaksanakan ujian.</p>
    <p><blink>Numpang exist!!!</blink></p>
    <p><a href="http://www.facebook.com/agusumarna"><img src="images/facebook-agus.jpg" width="124" height="213"></a><br />
      </p>
</div>

