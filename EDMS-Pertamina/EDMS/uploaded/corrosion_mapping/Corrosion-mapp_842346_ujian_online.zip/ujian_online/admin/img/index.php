<?php  //restricted Ares! ?>
<script language="javascript">document.location.href="../index.php";</script>